using Microsoft.Extensions.Configuration;
using HRMSystem.DAL;
namespace HRMSystem.Ying
{
    internal static class Program
    {
        /// <summary>
        ///  The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            var builder=new ConfigurationBuilder()
                .SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile("appsetting.json", false, true);
            ConfigurationAccessor.Configuration= builder.Build();
            builder.SetBasePath(Directory.GetCurrentDirectory());
            // To customize application configuration such as set high DPI settings or default font,
            // see https://aka.ms/applicationconfiguration.
            ApplicationConfiguration.Initialize();
            //Application.Run(new FormMain());
            Application.Run(new FormMain());
        }
    }
}