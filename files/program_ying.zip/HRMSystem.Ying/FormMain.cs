﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows;
using HRMSystem.Model;


namespace HRMSystem.Ying
{
    public partial class FormMain : Form
    {
        public FormMain()
        {
            InitializeComponent();
            this.IsMdiContainer = true;
        }
        private void FormMain_Load(object sender, EventArgs e)
        {
            FormLogin formlogin = new FormLogin();
            formlogin.ShowDialog();
            if (formlogin.DialogResult != DialogResult.OK)
            {
                Environment.Exit(0);
            }
            LoginUserInfo? lui = LoginUserInfo.GetInstance();
            if (lui != null)
            {
                tsslInfo.Text = $"欢迎{lui.LoginUser.RealName}登录本系统,登录时间为{DateTime.Now.ToString()}";
            }
            if (formlogin.GetUserName() != "admin")
            {
                tsml_AdminMenu.Visible = false;
            }

        }
        private void OpenChangePasswordForm()
        {
            Form_Change_password formChangePassword = new Form_Change_password();
            formChangePassword.MdiParent = this;
            formChangePassword.Text = "密码修改";
            formChangePassword.Show();
        }
        private void OpenResetPasswordForm()
        {
            Form_Reset_Password formresetpassword = new Form_Reset_Password();
            formresetpassword.MdiParent = this;
            formresetpassword.Text = "密码重置";
            formresetpassword.Show();
        }

        private void 修改密码ToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            OpenChangePasswordForm();
        }

        private void 退出ToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("确认退出吗", "提示", MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes)
            {
                this.Close();
            }

        }

        private void tsmlResetPassword_Click(object sender, EventArgs e)
        {
            OpenResetPasswordForm();
        }

        private void tsmlLogQuery_Click(object sender, EventArgs e)
        {
            FormLogQuery flq = new FormLogQuery();
            flq.MdiParent = this;
            flq.Show();
        }

        private void tsmlDepartmentManage_Click(object sender, EventArgs e)
        {
            Form_Department_Manage fd = new Form_Department_Manage();
            fd.MdiParent = this;
            fd.Show();
        }

        private void 日志迁移ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form_Log_Migration flm = new Form_Log_Migration();
            flm.MdiParent = this;
            flm.Show();
        }

        private void 员工管理ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form_Employee_Management fem = new Form_Employee_Management();
            fem.MdiParent = this;
            fem.Show();
        }
    }
}
