﻿namespace HRMSystem.Ying
{
    partial class FormLogQuery
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dataGridView = new DataGridView();
            labelTotal = new Label();
            label_previous = new Label();
            label_next = new Label();
            textBox_current = new TextBox();
            label_go = new Label();
            label_total = new Label();
            ((System.ComponentModel.ISupportInitialize)dataGridView).BeginInit();
            SuspendLayout();
            // 
            // dataGridView
            // 
            dataGridView.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView.Location = new Point(12, 12);
            dataGridView.Name = "dataGridView";
            dataGridView.RowHeadersWidth = 82;
            dataGridView.RowTemplate.Height = 40;
            dataGridView.Size = new Size(1354, 866);
            dataGridView.TabIndex = 0;
            // 
            // labelTotal
            // 
            labelTotal.AutoSize = true;
            labelTotal.Location = new Point(75, 898);
            labelTotal.Name = "labelTotal";
            labelTotal.Size = new Size(82, 31);
            labelTotal.TabIndex = 1;
            labelTotal.Text = "label1";
            labelTotal.Click += labelTotal_Click;
            // 
            // label_previous
            // 
            label_previous.AutoSize = true;
            label_previous.Location = new Point(403, 898);
            label_previous.Name = "label_previous";
            label_previous.Size = new Size(86, 31);
            label_previous.TabIndex = 2;
            label_previous.Text = "上一页";
            label_previous.Click += label_previous_Click;
            // 
            // label_next
            // 
            label_next.AutoSize = true;
            label_next.Location = new Point(593, 898);
            label_next.Name = "label_next";
            label_next.Size = new Size(86, 31);
            label_next.TabIndex = 3;
            label_next.Text = "下一页";
            label_next.Click += label_next_Click;
            // 
            // textBox_current
            // 
            textBox_current.Location = new Point(916, 902);
            textBox_current.Name = "textBox_current";
            textBox_current.Size = new Size(80, 38);
            textBox_current.TabIndex = 4;
            textBox_current.TextAlign = HorizontalAlignment.Right;
            // 
            // label_go
            // 
            label_go.AutoSize = true;
            label_go.Location = new Point(1094, 905);
            label_go.Name = "label_go";
            label_go.Size = new Size(62, 31);
            label_go.TabIndex = 5;
            label_go.Text = "跳转";
            label_go.Click += label_go_Click;
            // 
            // label_total
            // 
            label_total.AutoSize = true;
            label_total.Location = new Point(990, 905);
            label_total.Name = "label_total";
            label_total.Size = new Size(82, 31);
            label_total.TabIndex = 6;
            label_total.Text = "label1";
            // 
            // FormLogQuery
            // 
            AutoScaleDimensions = new SizeF(14F, 31F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1372, 958);
            Controls.Add(label_total);
            Controls.Add(label_go);
            Controls.Add(textBox_current);
            Controls.Add(label_next);
            Controls.Add(label_previous);
            Controls.Add(labelTotal);
            Controls.Add(dataGridView);
            Name = "FormLogQuery";
            Text = "日志查询";
            Load += FormLogQuery_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridView).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dataGridView;
        private Label labelTotal;
        private Label label_previous;
        private Label label_next;
        private TextBox textBox_current;
        private Label label_go;
        private Label label_total;
    }
}