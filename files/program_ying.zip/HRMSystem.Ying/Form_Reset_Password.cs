﻿using HRMSystem.BLL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HRMSystem.Ying
{
    public partial class Form_Reset_Password : Form
    {
        public Form_Reset_Password()
        {
            InitializeComponent();
        }

        private void buttonComfirm_Click(object sender, EventArgs e)
        {
            string un = textBox_UserName.Text;
            string rp = textBox_ResetPassword.Text;
            LoginUser lu = new LoginUser(un, "", rp);
            int rowsAffected = lu.Reset_Password_IsValid();
            if (rowsAffected > 0)
            {
                CommonHelper.ShowSuccessMessageBox("密码修改成功!!!");

            }
            else
            {
                CommonHelper.ShowFailMessageBox("用户名不存在!");
            }
        }

        private void Form_Reset_Password_Load(object sender, EventArgs e)
        {

        }

        private void buttonCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
