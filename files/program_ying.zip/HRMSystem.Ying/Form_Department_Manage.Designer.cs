﻿namespace HRMSystem.Ying
{
    partial class Form_Department_Manage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dataGridView_DepartmentManage = new DataGridView();
            buttonAdd = new Button();
            buttonDelete = new Button();
            buttonEdit = new Button();
            buttonquery = new Button();
            textBoxDepartment = new TextBox();
            buttonRefresh = new Button();
            label1 = new Label();
            ((System.ComponentModel.ISupportInitialize)dataGridView_DepartmentManage).BeginInit();
            SuspendLayout();
            // 
            // dataGridView_DepartmentManage
            // 
            dataGridView_DepartmentManage.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView_DepartmentManage.Location = new Point(-2, -1);
            dataGridView_DepartmentManage.Name = "dataGridView_DepartmentManage";
            dataGridView_DepartmentManage.RowHeadersWidth = 82;
            dataGridView_DepartmentManage.RowTemplate.Height = 40;
            dataGridView_DepartmentManage.Size = new Size(668, 654);
            dataGridView_DepartmentManage.TabIndex = 0;
            // 
            // buttonAdd
            // 
            buttonAdd.Location = new Point(760, 135);
            buttonAdd.Name = "buttonAdd";
            buttonAdd.Size = new Size(260, 122);
            buttonAdd.TabIndex = 1;
            buttonAdd.Text = "添加";
            buttonAdd.UseVisualStyleBackColor = true;
            buttonAdd.Click += buttonAdd_Click;
            // 
            // buttonDelete
            // 
            buttonDelete.Location = new Point(760, 642);
            buttonDelete.Name = "buttonDelete";
            buttonDelete.Size = new Size(260, 122);
            buttonDelete.TabIndex = 2;
            buttonDelete.Text = "删除";
            buttonDelete.UseVisualStyleBackColor = true;
            buttonDelete.Click += buttonDelete_Click;
            // 
            // buttonEdit
            // 
            buttonEdit.Location = new Point(760, 304);
            buttonEdit.Name = "buttonEdit";
            buttonEdit.Size = new Size(260, 122);
            buttonEdit.TabIndex = 3;
            buttonEdit.Text = "修改";
            buttonEdit.UseVisualStyleBackColor = true;
            buttonEdit.Click += buttonEdit_Click;
            // 
            // buttonquery
            // 
            buttonquery.Location = new Point(760, 473);
            buttonquery.Name = "buttonquery";
            buttonquery.Size = new Size(260, 122);
            buttonquery.TabIndex = 4;
            buttonquery.Text = "查询";
            buttonquery.UseVisualStyleBackColor = true;
            buttonquery.Click += buttonquery_Click;
            // 
            // textBoxDepartment
            // 
            textBoxDepartment.Location = new Point(760, 50);
            textBoxDepartment.Name = "textBoxDepartment";
            textBoxDepartment.Size = new Size(260, 38);
            textBoxDepartment.TabIndex = 5;
            // 
            // buttonRefresh
            // 
            buttonRefresh.Location = new Point(28, 681);
            buttonRefresh.Name = "buttonRefresh";
            buttonRefresh.Size = new Size(644, 84);
            buttonRefresh.TabIndex = 6;
            buttonRefresh.Text = "刷新";
            buttonRefresh.UseVisualStyleBackColor = true;
            buttonRefresh.Click += buttonRefresh_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(672, 53);
            label1.Name = "label1";
            label1.Size = new Size(92, 31);
            label1.TabIndex = 7;
            label1.Text = "输入框:";
            // 
            // Form_DepartmentManage
            // 
            AutoScaleDimensions = new SizeF(14F, 31F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1140, 800);
            Controls.Add(label1);
            Controls.Add(buttonRefresh);
            Controls.Add(textBoxDepartment);
            Controls.Add(buttonquery);
            Controls.Add(buttonEdit);
            Controls.Add(buttonDelete);
            Controls.Add(buttonAdd);
            Controls.Add(dataGridView_DepartmentManage);
            Name = "Form_DepartmentManage";
            Text = "部门管理";
            Load += Form_DepartmentManage_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridView_DepartmentManage).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dataGridView_DepartmentManage;
        private Button buttonAdd;
        private Button buttonDelete;
        private Button buttonEdit;
        private Button buttonquery;
        private TextBox textBoxDepartment;
        private Button buttonRefresh;
        private Label label1;
    }
}