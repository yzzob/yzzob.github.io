﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;
using HRMSystem.BLL;
namespace HRMSystem.Ying
{
    public partial class FormLogin : Form
    {
        public FormLogin()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string un = textBoxUsername.Text;
            string pwd = CommonHelper.GetMD5(textBoxPassword.Text);
            LoginUser lu = new LoginUser(un,pwd,"0");
            if (lu.IsValid())
            {
                CommonHelper.ShowSuccessMessageBox("欢迎使用本系统！");
                this.DialogResult = DialogResult.OK;
            }
            else
            {
                CommonHelper.ShowFailMessageBox("用户名或密码不正确！");
                textBoxPassword.Text = "";
            }
        }
        public string GetUserName()
        {
            return textBoxUsername.Text;
        }


        private void buttoncancel_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
        }

        private void FormLogin_Load(object sender, EventArgs e)
        {

        }
    }
}
