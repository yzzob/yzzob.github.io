﻿using HRMSystem.DAL;
using HRMSystem.Model;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HRMSystem.Ying
{
    public partial class Form_Employee_Management : Form
    {
        EmployeeManagementService ems = new EmployeeManagementService();
        public Form_Employee_Management()
        {
            InitializeComponent();
        }

        private void buttonSearch_Click(object sender, EventArgs e)
        {
            ConditionForSearch cfs = new ConditionForSearch();
            dataGridView.DataSource = null;
            if (checkBox_Name.Checked) cfs.Name = textBox_Name.Text;
            if (checkBox_Dep.Checked)
            {
                cfs.DepartmentId = ems.GetGuid(comboBox_Department.Text);
            }
            if (checkBox_Time.Checked)
            {
                if (!comboBox_Time_Start.Text.IsNullOrEmpty())
                {
                    cfs.InDateFrom = comboBox_Time_Start.Text;
                }

                if (!comboBox_Time_End.Text.IsNullOrEmpty())
                {
                    cfs.InDateTo = comboBox_Time_End.Text;
                }
            }
            dataGridView.DataSource = ems.GetData(cfs);
            //string labelValue = $"Name: {cfs.Name}, DepartmentId: {cfs.DepartmentId}, InDateFrom: {cfs.InDateFrom}, InDateTo: {cfs.InDateTo}";
            //textBox1.Text = labelValue;
        }

        private void Form_Employee_Management_Load(object sender, EventArgs e)
        {
            HashSet<string> set = ems.GetDepartment();
            foreach (string departmentName in set)
            {
                comboBox_Department.Items.Add(departmentName);
            }
            HashSet<DateTime> set_time = ems.GetInDay();
            foreach (DateTime inday in set_time)
            {
                comboBox_Time_Start.Items.Add(inday);
                comboBox_Time_End.Items.Add(inday);
            }
        }

        private void groupBox_Search_Conditions_Enter(object sender, EventArgs e)
        {

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
        }

        private void toolStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void textBox_Name_TextChanged(object sender, EventArgs e)
        {

        }

        private void checkBox_Dep_CheckedChanged(object sender, EventArgs e)
        {
        }

        private void checkBox_Time_CheckedChanged(object sender, EventArgs e)
        {
        }
    }
}
