﻿namespace HRMSystem.Ying
{
    partial class Form_Change_password
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            textBox_UserName = new TextBox();
            textBox_OldPassword = new TextBox();
            textBox_NewPassword = new TextBox();
            textBox_ComfirePassword = new TextBox();
            button_Confirmation = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(136, 124);
            label1.Name = "label1";
            label1.Size = new Size(92, 31);
            label1.TabIndex = 0;
            label1.Text = "用户名:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(136, 204);
            label2.Name = "label2";
            label2.Size = new Size(92, 31);
            label2.TabIndex = 1;
            label2.Text = "原密码:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(136, 290);
            label3.Name = "label3";
            label3.Size = new Size(92, 31);
            label3.TabIndex = 2;
            label3.Text = "新密码:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(116, 374);
            label4.Name = "label4";
            label4.Size = new Size(123, 31);
            label4.TabIndex = 3;
            label4.Text = "\u007f确认密码:";
            // 
            // textBox_UserName
            // 
            textBox_UserName.Location = new Point(278, 124);
            textBox_UserName.Name = "textBox_UserName";
            textBox_UserName.Size = new Size(368, 38);
            textBox_UserName.TabIndex = 4;
            // 
            // textBox_OldPassword
            // 
            textBox_OldPassword.Location = new Point(278, 204);
            textBox_OldPassword.Name = "textBox_OldPassword";
            textBox_OldPassword.Size = new Size(368, 38);
            textBox_OldPassword.TabIndex = 5;
            // 
            // textBox_NewPassword
            // 
            textBox_NewPassword.Location = new Point(278, 290);
            textBox_NewPassword.Name = "textBox_NewPassword";
            textBox_NewPassword.PasswordChar = '*';
            textBox_NewPassword.Size = new Size(368, 38);
            textBox_NewPassword.TabIndex = 6;
            // 
            // textBox_ComfirePassword
            // 
            textBox_ComfirePassword.Location = new Point(278, 367);
            textBox_ComfirePassword.Name = "textBox_ComfirePassword";
            textBox_ComfirePassword.PasswordChar = '*';
            textBox_ComfirePassword.Size = new Size(368, 38);
            textBox_ComfirePassword.TabIndex = 7;
            // 
            // button_Confirmation
            // 
            button_Confirmation.Location = new Point(256, 466);
            button_Confirmation.Name = "button_Confirmation";
            button_Confirmation.Size = new Size(230, 62);
            button_Confirmation.TabIndex = 8;
            button_Confirmation.Text = "确认";
            button_Confirmation.UseVisualStyleBackColor = true;
            button_Confirmation.Click += button_Confirmation_Click;
            // 
            // Form_Change_password
            // 
            AutoScaleDimensions = new SizeF(14F, 31F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(750, 606);
            Controls.Add(button_Confirmation);
            Controls.Add(textBox_ComfirePassword);
            Controls.Add(textBox_NewPassword);
            Controls.Add(textBox_OldPassword);
            Controls.Add(textBox_UserName);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "Form_Change_password";
            Text = "修改密码";
            Load += Form_Change_password_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private TextBox textBox_UserName;
        private TextBox textBox_OldPassword;
        private TextBox textBox_NewPassword;
        private TextBox textBox_ComfirePassword;
        private Button button_Confirmation;
    }
}