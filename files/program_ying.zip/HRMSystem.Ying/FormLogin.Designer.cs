﻿namespace HRMSystem.Ying
{
    partial class FormLogin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            buttonlogin = new Button();
            buttoncancel = new Button();
            label1 = new Label();
            label2 = new Label();
            textBoxUsername = new TextBox();
            textBoxPassword = new TextBox();
            SuspendLayout();
            // 
            // buttonlogin
            // 
            buttonlogin.Location = new Point(114, 302);
            buttonlogin.Margin = new Padding(6, 5, 6, 5);
            buttonlogin.Name = "buttonlogin";
            buttonlogin.Size = new Size(188, 80);
            buttonlogin.TabIndex = 0;
            buttonlogin.Text = "登录";
            buttonlogin.UseVisualStyleBackColor = true;
            buttonlogin.Click += button1_Click;
            // 
            // buttoncancel
            // 
            buttoncancel.Location = new Point(410, 302);
            buttoncancel.Margin = new Padding(6, 5, 6, 5);
            buttoncancel.Name = "buttoncancel";
            buttoncancel.Size = new Size(188, 80);
            buttoncancel.TabIndex = 1;
            buttoncancel.Text = "取消";
            buttoncancel.UseVisualStyleBackColor = true;
            buttoncancel.Click += buttoncancel_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(140, 96);
            label1.Margin = new Padding(6, 0, 6, 0);
            label1.Name = "label1";
            label1.Size = new Size(110, 31);
            label1.TabIndex = 2;
            label1.Text = "用户名：";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(164, 187);
            label2.Margin = new Padding(6, 0, 6, 0);
            label2.Name = "label2";
            label2.Size = new Size(86, 31);
            label2.TabIndex = 3;
            label2.Text = "密码：";
            // 
            // textBoxUsername
            // 
            textBoxUsername.Location = new Point(264, 96);
            textBoxUsername.Margin = new Padding(6, 5, 6, 5);
            textBoxUsername.Name = "textBoxUsername";
            textBoxUsername.Size = new Size(262, 38);
            textBoxUsername.TabIndex = 4;
            textBoxUsername.Text = "admin";
            // 
            // textBoxPassword
            // 
            textBoxPassword.Location = new Point(264, 187);
            textBoxPassword.Margin = new Padding(6, 5, 6, 5);
            textBoxPassword.Name = "textBoxPassword";
            textBoxPassword.PasswordChar = '*';
            textBoxPassword.Size = new Size(262, 38);
            textBoxPassword.TabIndex = 5;
            textBoxPassword.Text = "123";
            // 
            // FormLogin
            // 
            AutoScaleDimensions = new SizeF(14F, 31F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(728, 461);
            Controls.Add(textBoxPassword);
            Controls.Add(textBoxUsername);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(buttoncancel);
            Controls.Add(buttonlogin);
            Margin = new Padding(6, 5, 6, 5);
            Name = "FormLogin";
            Text = "登录";
            Load += FormLogin_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button buttonlogin;
        private Button buttoncancel;
        private Label label1;
        private Label label2;
        private TextBox textBoxUsername;
        private TextBox textBoxPassword;
    }
}