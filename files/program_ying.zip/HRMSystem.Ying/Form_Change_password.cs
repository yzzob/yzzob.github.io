﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using HRMSystem.BLL;
using HRMSystem.Model;
namespace HRMSystem.Ying
{
    public partial class Form_Change_password : Form
    {
        public Form_Change_password()
        {
            InitializeComponent();
        }

        private void Form_Change_password_Load(object sender, EventArgs e)
        {

        }

        private void button_Confirmation_Click(object sender, EventArgs e)
        {
            string un = textBox_UserName.Text;
            string old_pwd = CommonHelper.GetMD5(textBox_OldPassword.Text);
            string new_pwd = textBox_NewPassword.Text;
            string new_pwd_2 = textBox_ComfirePassword.Text;
            if (string.IsNullOrEmpty(textBox_ComfirePassword.Text) || string.IsNullOrEmpty(textBox_NewPassword.Text) || string.IsNullOrEmpty(textBox_OldPassword.Text) || string.IsNullOrEmpty(textBox_UserName.Text))
            {
                CommonHelper.ShowFailMessageBox("有信息为空");
            }
            else
            {
                LoginUser lu = new LoginUser(un, old_pwd, new_pwd);
                if (lu.IsValid())
                {
                    if (textBox_ComfirePassword.Text != textBox_NewPassword.Text)
                    {
                        CommonHelper.ShowFailMessageBox("新密码两次输入不一致");
                        textBox_ComfirePassword.Clear();
                    }
                    else
                    {
                        int rowsAffected = lu.Change_Password_IsValid();
                        if (rowsAffected > 0)
                        {
                            CommonHelper.ShowSuccessMessageBox("密码修改成功");

                        }
                        else
                        {
                            CommonHelper.ShowFailMessageBox("密码修改失败");
                        }
                        textBox_ComfirePassword.Clear();
                        textBox_NewPassword.Clear();
                        textBox_OldPassword.Clear();
                        textBox_UserName.Clear();
                    }
                }
                else
                {
                    CommonHelper.ShowFailMessageBox("用户名或密码不正确！");
                }
            }
           
        }

    }
}
