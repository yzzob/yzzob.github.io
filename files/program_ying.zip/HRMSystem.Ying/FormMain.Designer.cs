﻿namespace HRMSystem.Ying
{
    partial class FormMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            menuStrip1 = new MenuStrip();
            系统功能ToolStripMenuItem = new ToolStripMenuItem();
            修改密码ToolStripMenuItem1 = new ToolStripMenuItem();
            退出ToolStripMenuItem1 = new ToolStripMenuItem();
            tsml_AdminMenu = new ToolStripMenuItem();
            tsmlResetPassword = new ToolStripMenuItem();
            tsmlLogQuery = new ToolStripMenuItem();
            tsmlDepartmentManage = new ToolStripMenuItem();
            员工管理ToolStripMenuItem = new ToolStripMenuItem();
            日志迁移ToolStripMenuItem = new ToolStripMenuItem();
            statusStrip1 = new StatusStrip();
            toolStripStatusLabel1 = new ToolStripStatusLabel();
            tsslInfo = new ToolStripStatusLabel();
            menuStrip1.SuspendLayout();
            statusStrip1.SuspendLayout();
            SuspendLayout();
            // 
            // menuStrip1
            // 
            menuStrip1.ImageScalingSize = new Size(32, 32);
            menuStrip1.Items.AddRange(new ToolStripItem[] { 系统功能ToolStripMenuItem, tsml_AdminMenu });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Size = new Size(1992, 42);
            menuStrip1.TabIndex = 1;
            menuStrip1.Text = "menuStrip1";
            // 
            // 系统功能ToolStripMenuItem
            // 
            系统功能ToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { 修改密码ToolStripMenuItem1, 退出ToolStripMenuItem1 });
            系统功能ToolStripMenuItem.Name = "系统功能ToolStripMenuItem";
            系统功能ToolStripMenuItem.Size = new Size(130, 38);
            系统功能ToolStripMenuItem.Text = "系统功能";
            // 
            // 修改密码ToolStripMenuItem1
            // 
            修改密码ToolStripMenuItem1.Name = "修改密码ToolStripMenuItem1";
            修改密码ToolStripMenuItem1.Size = new Size(243, 44);
            修改密码ToolStripMenuItem1.Text = "修改密码";
            修改密码ToolStripMenuItem1.Click += 修改密码ToolStripMenuItem1_Click;
            // 
            // 退出ToolStripMenuItem1
            // 
            退出ToolStripMenuItem1.Name = "退出ToolStripMenuItem1";
            退出ToolStripMenuItem1.Size = new Size(243, 44);
            退出ToolStripMenuItem1.Text = "退出";
            退出ToolStripMenuItem1.Click += 退出ToolStripMenuItem1_Click;
            // 
            // tsml_AdminMenu
            // 
            tsml_AdminMenu.DropDownItems.AddRange(new ToolStripItem[] { tsmlResetPassword, tsmlLogQuery, tsmlDepartmentManage, 员工管理ToolStripMenuItem, 日志迁移ToolStripMenuItem });
            tsml_AdminMenu.Name = "tsml_AdminMenu";
            tsml_AdminMenu.Size = new Size(154, 38);
            tsml_AdminMenu.Text = "管理员菜单";
            // 
            // tsmlResetPassword
            // 
            tsmlResetPassword.Name = "tsmlResetPassword";
            tsmlResetPassword.Size = new Size(359, 44);
            tsmlResetPassword.Text = "重置操作员密码";
            tsmlResetPassword.Click += tsmlResetPassword_Click;
            // 
            // tsmlLogQuery
            // 
            tsmlLogQuery.Name = "tsmlLogQuery";
            tsmlLogQuery.Size = new Size(359, 44);
            tsmlLogQuery.Text = "日志查询";
            tsmlLogQuery.Click += tsmlLogQuery_Click;
            // 
            // tsmlDepartmentManage
            // 
            tsmlDepartmentManage.Name = "tsmlDepartmentManage";
            tsmlDepartmentManage.Size = new Size(359, 44);
            tsmlDepartmentManage.Text = "部门管理";
            tsmlDepartmentManage.Click += tsmlDepartmentManage_Click;
            // 
            // 员工管理ToolStripMenuItem
            // 
            员工管理ToolStripMenuItem.Name = "员工管理ToolStripMenuItem";
            员工管理ToolStripMenuItem.Size = new Size(359, 44);
            员工管理ToolStripMenuItem.Text = "员工管理";
            员工管理ToolStripMenuItem.Click += 员工管理ToolStripMenuItem_Click;
            // 
            // 日志迁移ToolStripMenuItem
            // 
            日志迁移ToolStripMenuItem.Name = "日志迁移ToolStripMenuItem";
            日志迁移ToolStripMenuItem.Size = new Size(359, 44);
            日志迁移ToolStripMenuItem.Text = "日志迁移";
            日志迁移ToolStripMenuItem.Click += 日志迁移ToolStripMenuItem_Click;
            // 
            // statusStrip1
            // 
            statusStrip1.ImageScalingSize = new Size(32, 32);
            statusStrip1.Items.AddRange(new ToolStripItem[] { toolStripStatusLabel1, tsslInfo });
            statusStrip1.Location = new Point(0, 1113);
            statusStrip1.Name = "statusStrip1";
            statusStrip1.Size = new Size(1992, 41);
            statusStrip1.TabIndex = 2;
            statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabel1
            // 
            toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            toolStripStatusLabel1.Size = new Size(0, 31);
            // 
            // tsslInfo
            // 
            tsslInfo.Name = "tsslInfo";
            tsslInfo.Size = new Size(257, 31);
            tsslInfo.Text = "toolStripStatusLabel2";
            // 
            // FormMain
            // 
            AutoScaleDimensions = new SizeF(14F, 31F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1992, 1154);
            Controls.Add(statusStrip1);
            Controls.Add(menuStrip1);
            MainMenuStrip = menuStrip1;
            Margin = new Padding(6, 5, 6, 5);
            Name = "FormMain";
            Text = "主界面";
            Load += FormMain_Load;
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            statusStrip1.ResumeLayout(false);
            statusStrip1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private MenuStrip menuStrip1;
        private ToolStripMenuItem 系统功能ToolStripMenuItem;
        private ToolStripMenuItem 修改密码ToolStripMenuItem1;
        private ToolStripMenuItem 退出ToolStripMenuItem1;
        private ToolStripMenuItem tsml_AdminMenu;
        private ToolStripMenuItem tsmlResetPassword;
        private StatusStrip statusStrip1;
        private ToolStripStatusLabel toolStripStatusLabel1;
        private ToolStripStatusLabel tsslInfo;
        private ToolStripMenuItem tsmlLogQuery;
        private ToolStripMenuItem tsmlDepartmentManage;
        private ToolStripMenuItem 员工管理ToolStripMenuItem;
        private ToolStripMenuItem 日志迁移ToolStripMenuItem;
    }
}