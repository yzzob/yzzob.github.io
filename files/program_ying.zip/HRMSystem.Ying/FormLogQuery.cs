﻿using HRMSystem.DAL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Linq;
namespace HRMSystem.Ying
{
    public partial class FormLogQuery : Form
    {
        private int currentPageNo = 1;
        private int NUM_PER_PAGE = 10;
        private int totalPages = 0;
        OperationLogService logServ = new OperationLogService();
        private int total_num = 0;
        public FormLogQuery()
        {
            InitializeComponent();
        }

        private void FormLogQuery_Load(object sender, EventArgs e)
        {
            dataGridView.DataSource = logServ.GetLogList(1, 10);
            int pages = logServ.GetLogCount() % NUM_PER_PAGE == 0 ? logServ.GetLogCount() / NUM_PER_PAGE : logServ.GetLogCount() / NUM_PER_PAGE + 1;
            labelTotal.Text = "共计:" + pages.ToString() + "页";
            totalPages = pages;
            total_num=logServ.GetLogCount();
            label_total.Text = $"/{pages}";
            textBox_current.Text = "1";
        }
        private void labelTotal_Click(object sender, EventArgs e)
        {


        }
        private void show(int PageNumber)
        {
            dataGridView.DataSource = null;
            dataGridView.DataSource = logServ.GetLogList(PageNumber, 10);
            textBox_current.Text = currentPageNo.ToString();
        }
        private void label_previous_Click(object sender, EventArgs e)
        {
            if (currentPageNo == 1)
            {
                currentPageNo = 1;
            }
            else
            {
                currentPageNo = currentPageNo - 1;
            }
            show(currentPageNo);
        }

        private void label_next_Click(object sender, EventArgs e)
        {
            if (currentPageNo == totalPages)
            {
                currentPageNo = totalPages;
            }
            else
            {
                currentPageNo = currentPageNo + 1;
            }
            show(currentPageNo);
        }

        private void label_go_Click(object sender, EventArgs e)
        {
            int current_page;
            if (int.TryParse(textBox_current.Text, out current_page))
            {
                currentPageNo= current_page;
                show(currentPageNo);
            }
            else
            {
                CommonHelper.ShowFailMessageBox("输入格式有误,请重新输入!");
            }


        }
    }
}
