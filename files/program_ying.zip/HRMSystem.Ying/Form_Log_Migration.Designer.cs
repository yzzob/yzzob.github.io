﻿namespace HRMSystem.Ying
{
    partial class Form_Log_Migration
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            comboBox_log = new ComboBox();
            button_comfire = new Button();
            SuspendLayout();
            // 
            // comboBox_log
            // 
            comboBox_log.FormattingEnabled = true;
            comboBox_log.Location = new Point(45, 74);
            comboBox_log.Name = "comboBox_log";
            comboBox_log.Size = new Size(358, 39);
            comboBox_log.TabIndex = 0;
            comboBox_log.SelectedIndexChanged += comboBox1_SelectedIndexChanged;
            // 
            // button_comfire
            // 
            button_comfire.Location = new Point(441, 356);
            button_comfire.Name = "button_comfire";
            button_comfire.Size = new Size(158, 74);
            button_comfire.TabIndex = 1;
            button_comfire.Text = "确定";
            button_comfire.UseVisualStyleBackColor = true;
            button_comfire.Click += button_comfire_Click;
            // 
            // Form_Log_Migration
            // 
            AutoScaleDimensions = new SizeF(14F, 31F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(704, 518);
            Controls.Add(button_comfire);
            Controls.Add(comboBox_log);
            Name = "Form_Log_Migration";
            Text = "日志迁移";
            Load += Form_Log_Migration_Load;
            ResumeLayout(false);
        }

        #endregion

        private ComboBox comboBox_log;
        private Button button_comfire;
    }
}