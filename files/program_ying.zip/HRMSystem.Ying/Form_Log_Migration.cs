﻿using HRMSystem.DAL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace HRMSystem.Ying
{
    public partial class Form_Log_Migration : Form
    {
        LogMigrationService lms = new LogMigrationService();
        public Form_Log_Migration()
        {
            InitializeComponent();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Form_Log_Migration_Load(object sender, EventArgs e)
        {
            HashSet<DateTime> logs = lms.get_log();
            foreach (DateTime log in logs)
            {
                comboBox_log.Items.Add(log);
            }
        }

        private void button_comfire_Click(object sender, EventArgs e)
        {
            if (comboBox_log.SelectedItem == null)
            {
                CommonHelper.ShowFailMessageBox("请选择日期");
            }
            else
            {
                DateTime selectedDateTime = (DateTime)comboBox_log.SelectedItem;
                lms.move_log(selectedDateTime);
                CommonHelper.ShowSuccessMessageBox("移动成功!!!");
                comboBox_log.SelectedItem=null;
            }
        }
    }
}
