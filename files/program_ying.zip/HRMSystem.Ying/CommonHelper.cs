﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace HRMSystem.Ying
{
    internal class CommonHelper
    {
        public static string GetMD5(string input)
        {
            MD5 md5 = MD5.Create();
            byte[] bytesInput = Encoding.UTF8.GetBytes(input);
            byte[] bytesMd5 = md5.ComputeHash(bytesInput);
            StringBuilder sb= new StringBuilder();
            foreach(byte b in bytesMd5)
            {
                sb.Append(b.ToString("x2"));
            }
            return sb.ToString();
        }
        public static void ShowSuccessMessageBox(string message)
        {
            MessageBox.Show(message, "成功提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        public static void ShowFailMessageBox(string message)
        {
            MessageBox.Show(message, "错误提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

    }
}
