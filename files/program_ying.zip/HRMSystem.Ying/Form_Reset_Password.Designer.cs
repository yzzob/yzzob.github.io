﻿namespace HRMSystem.Ying
{
    partial class Form_Reset_Password
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            buttonComfirm = new Button();
            textBox_UserName = new TextBox();
            textBox_ResetPassword = new TextBox();
            buttonCancel = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(176, 113);
            label1.Name = "label1";
            label1.Size = new Size(92, 31);
            label1.TabIndex = 0;
            label1.Text = "用户名:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(104, 199);
            label2.Name = "label2";
            label2.Size = new Size(164, 31);
            label2.TabIndex = 1;
            label2.Text = "重置后的密码:";
            // 
            // buttonComfirm
            // 
            buttonComfirm.Location = new Point(76, 305);
            buttonComfirm.Name = "buttonComfirm";
            buttonComfirm.Size = new Size(248, 86);
            buttonComfirm.TabIndex = 2;
            buttonComfirm.Text = "确认";
            buttonComfirm.UseVisualStyleBackColor = true;
            buttonComfirm.Click += buttonComfirm_Click;
            // 
            // textBox_UserName
            // 
            textBox_UserName.Location = new Point(289, 113);
            textBox_UserName.Name = "textBox_UserName";
            textBox_UserName.Size = new Size(288, 38);
            textBox_UserName.TabIndex = 3;
            // 
            // textBox_ResetPassword
            // 
            textBox_ResetPassword.Location = new Point(289, 199);
            textBox_ResetPassword.Name = "textBox_ResetPassword";
            textBox_ResetPassword.Size = new Size(288, 38);
            textBox_ResetPassword.TabIndex = 4;
            textBox_ResetPassword.Text = "666";
            // 
            // buttonCancel
            // 
            buttonCancel.Location = new Point(453, 305);
            buttonCancel.Name = "buttonCancel";
            buttonCancel.Size = new Size(248, 86);
            buttonCancel.TabIndex = 5;
            buttonCancel.Text = "取消";
            buttonCancel.UseVisualStyleBackColor = true;
            buttonCancel.Click += buttonCancel_Click;
            // 
            // Form_Reset_Password
            // 
            AutoScaleDimensions = new SizeF(14F, 31F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(814, 454);
            Controls.Add(buttonCancel);
            Controls.Add(textBox_ResetPassword);
            Controls.Add(textBox_UserName);
            Controls.Add(buttonComfirm);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "Form_Reset_Password";
            Text = "重置操作员密码";
            Load += Form_Reset_Password_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Button buttonComfirm;
        private TextBox textBox_UserName;
        private TextBox textBox_ResetPassword;
        private Button buttonCancel;
    }
}