﻿using HRMSystem.DAL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HRMSystem.Ying
{
    public partial class Form_Department_Manage : Form
    {
        DepartmentManageService dms = new DepartmentManageService();
        public Form_Department_Manage()
        {
            InitializeComponent();
        }
        private void load()
        {
            dataGridView_DepartmentManage.DataSource = dms.GetDepatmentList();
        }
        private void Form_DepartmentManage_Load(object sender, EventArgs e)
        {
            load();
        }

        private void buttonAdd_Click(object sender, EventArgs e)
        {
            string departmentName = textBoxDepartment.Text;

            if (!string.IsNullOrEmpty(departmentName))
            {
                DataTable updatedTable = dms.AddDepartment(departmentName);
                dataGridView_DepartmentManage.DataSource = updatedTable;
                dataGridView_DepartmentManage.Refresh();
                load();
                CommonHelper.ShowSuccessMessageBox("添加成功!");
            }
            else
            {
                CommonHelper.ShowFailMessageBox("请输入要添加的部门名称!");
            }
        }
        private void buttonDelete_Click(object sender, EventArgs e)
        {
            if (dataGridView_DepartmentManage.SelectedRows.Count > 0)
            {
                int count = dataGridView_DepartmentManage.SelectedRows.Count;
                DialogResult result = MessageBox.Show($"是否删除选中的{count}条记录？", "确认删除", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                {
                    List<Guid> ids = new List<Guid>();
                    foreach (DataGridViewRow row in dataGridView_DepartmentManage.SelectedRows)
                    {
                        Guid id = (Guid)row.Cells["编号"].Value;
                        ids.Add(id);
                    }
                    dms.DeleteDepartments(ids);
                    load();
                    CommonHelper.ShowSuccessMessageBox("删除成功!");
                }
            }
            else
            {
                CommonHelper.ShowFailMessageBox("请选中要删除的部门!");
            }
        }



        private void buttonRefresh_Click(object sender, EventArgs e)
        {
            load();
        }

        private void buttonquery_Click(object sender, EventArgs e)
        {
            if (textBoxDepartment.Text == string.Empty)
            {
                CommonHelper.ShowFailMessageBox("请输入要查询的部门名称");
            }
            else
            {
                DataTable dt = dms.QueryDepartment(textBoxDepartment.Text);
                dataGridView_DepartmentManage.DataSource = dt;
                CommonHelper.ShowSuccessMessageBox("查询成功!");
            }
        }


        private void buttonEdit_Click(object sender, EventArgs e)
        {
            if (dataGridView_DepartmentManage.SelectedRows.Count == 1)
            {
                string? oldName = dataGridView_DepartmentManage.SelectedRows[0].Cells["部门名称"].Value.ToString();
                if (oldName != string.Empty)
                {
                    dms.EditDepartments(oldName, textBoxDepartment.Text);
                    load();
                    CommonHelper.ShowSuccessMessageBox("修改成功!");
                }
                else
                {
                    CommonHelper.ShowFailMessageBox("请输入修改后的部门名称");
                }
            }
            else
            {
                CommonHelper.ShowFailMessageBox("一次更改一条记录");
            }
        }

    }
}
/*
using HRMSystem.DAL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HRMSystem.Ying
{
    public partial class Form_DepartmentManage : Form
    {
        DepartmentManageService dms = new DepartmentManageService();
        public Form_DepartmentManage()
        {
            InitializeComponent();
        }

        private void Form_DepartmentManage_Load(object sender, EventArgs e)
        {
            dataGridView_DepartmentManage.DataSource = dms.GetDepatmentList().Tables[0];
        }

        private void buttonSave_Click(object sender, EventArgs e)
        {
            foreach (DataGridViewRow row in dataGridView_DepartmentManage.Rows)
            {
                if (row.Cells["编号"].Value != null && row.Cells["部门名称"].Value != null)
                {
                    Guid id;
                    if (row.Cells["编号"].Value is Guid)
                    {
                        id = (Guid)row.Cells["编号"].Value;
                    }
                    else if (Guid.TryParse(row.Cells["编号"].Value.ToString(), out id))
                    {
                    }
                    else
                    {
                        MessageBox.Show("Invalid Guid format for ID");
                        return;
                    }

                    string name = row.Cells["部门名称"].Value.ToString();
                    dms.UpdateDepartment(id, name);
                }
            }
            CommonHelper.ShowSuccessMessageBox("保存成功!");
        }

        private void buttonRefresh_Click(object sender, EventArgs e)
        {
            dataGridView_DepartmentManage.DataSource = dms.GetDepatmentList().Tables[0];
        }

    }
} */