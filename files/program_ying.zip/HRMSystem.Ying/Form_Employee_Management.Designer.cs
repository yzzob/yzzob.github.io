﻿namespace HRMSystem.Ying
{
    partial class Form_Employee_Management
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form_Employee_Management));
            dataGridView = new DataGridView();
            groupBox_Search_Conditions = new GroupBox();
            button_Search = new Button();
            comboBox_Time_End = new ComboBox();
            label1 = new Label();
            comboBox_Time_Start = new ComboBox();
            comboBox_Department = new ComboBox();
            checkBox_Time = new CheckBox();
            checkBox_Dep = new CheckBox();
            checkBox_Name = new CheckBox();
            textBox_Name = new TextBox();
            toolStrip1 = new ToolStrip();
            toolStripButton2 = new ToolStripButton();
            toolStripButton3 = new ToolStripButton();
            toolStripButton_Delete = new ToolStripButton();
            toolStripButton4 = new ToolStripButton();
            textBox1 = new TextBox();
            ((System.ComponentModel.ISupportInitialize)dataGridView).BeginInit();
            groupBox_Search_Conditions.SuspendLayout();
            toolStrip1.SuspendLayout();
            SuspendLayout();
            // 
            // dataGridView
            // 
            dataGridView.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView.Location = new Point(32, 294);
            dataGridView.Name = "dataGridView";
            dataGridView.RowHeadersWidth = 82;
            dataGridView.RowTemplate.Height = 40;
            dataGridView.Size = new Size(1740, 530);
            dataGridView.TabIndex = 0;
            // 
            // groupBox_Search_Conditions
            // 
            groupBox_Search_Conditions.Controls.Add(button_Search);
            groupBox_Search_Conditions.Controls.Add(comboBox_Time_End);
            groupBox_Search_Conditions.Controls.Add(label1);
            groupBox_Search_Conditions.Controls.Add(comboBox_Time_Start);
            groupBox_Search_Conditions.Controls.Add(comboBox_Department);
            groupBox_Search_Conditions.Controls.Add(checkBox_Time);
            groupBox_Search_Conditions.Controls.Add(checkBox_Dep);
            groupBox_Search_Conditions.Controls.Add(checkBox_Name);
            groupBox_Search_Conditions.Controls.Add(textBox_Name);
            groupBox_Search_Conditions.Location = new Point(32, 78);
            groupBox_Search_Conditions.Name = "groupBox_Search_Conditions";
            groupBox_Search_Conditions.Size = new Size(1306, 210);
            groupBox_Search_Conditions.TabIndex = 1;
            groupBox_Search_Conditions.TabStop = false;
            groupBox_Search_Conditions.Text = "搜索条件";
            groupBox_Search_Conditions.Enter += groupBox_Search_Conditions_Enter;
            // 
            // button_Search
            // 
            button_Search.Location = new Point(547, 123);
            button_Search.Name = "button_Search";
            button_Search.Size = new Size(180, 58);
            button_Search.TabIndex = 14;
            button_Search.Text = "搜索";
            button_Search.UseVisualStyleBackColor = true;
            button_Search.Click += buttonSearch_Click;
            // 
            // comboBox_Time_End
            // 
            comboBox_Time_End.FormattingEnabled = true;
            comboBox_Time_End.Location = new Point(983, 57);
            comboBox_Time_End.Name = "comboBox_Time_End";
            comboBox_Time_End.Size = new Size(242, 39);
            comboBox_Time_End.TabIndex = 13;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(939, 63);
            label1.Name = "label1";
            label1.Size = new Size(38, 31);
            label1.TabIndex = 12;
            label1.Text = "到";
            // 
            // comboBox_Time_Start
            // 
            comboBox_Time_Start.FormattingEnabled = true;
            comboBox_Time_Start.Location = new Point(691, 62);
            comboBox_Time_Start.Name = "comboBox_Time_Start";
            comboBox_Time_Start.Size = new Size(242, 39);
            comboBox_Time_Start.TabIndex = 11;
            // 
            // comboBox_Department
            // 
            comboBox_Department.FormattingEnabled = true;
            comboBox_Department.Location = new Point(153, 134);
            comboBox_Department.Name = "comboBox_Department";
            comboBox_Department.Size = new Size(302, 39);
            comboBox_Department.TabIndex = 10;
            // 
            // checkBox_Time
            // 
            checkBox_Time.AutoSize = true;
            checkBox_Time.Location = new Point(547, 62);
            checkBox_Time.Name = "checkBox_Time";
            checkBox_Time.Size = new Size(148, 35);
            checkBox_Time.TabIndex = 8;
            checkBox_Time.Text = "入职时间:";
            checkBox_Time.UseVisualStyleBackColor = true;
            checkBox_Time.CheckedChanged += checkBox_Time_CheckedChanged;
            // 
            // checkBox_Dep
            // 
            checkBox_Dep.AutoSize = true;
            checkBox_Dep.Location = new Point(47, 136);
            checkBox_Dep.Name = "checkBox_Dep";
            checkBox_Dep.Size = new Size(100, 35);
            checkBox_Dep.TabIndex = 7;
            checkBox_Dep.Text = "部门:";
            checkBox_Dep.UseVisualStyleBackColor = true;
            checkBox_Dep.CheckedChanged += checkBox_Dep_CheckedChanged;
            // 
            // checkBox_Name
            // 
            checkBox_Name.AutoSize = true;
            checkBox_Name.Location = new Point(47, 59);
            checkBox_Name.Name = "checkBox_Name";
            checkBox_Name.Size = new Size(100, 35);
            checkBox_Name.TabIndex = 6;
            checkBox_Name.Text = "姓名:";
            checkBox_Name.UseVisualStyleBackColor = true;
            checkBox_Name.CheckedChanged += checkBox1_CheckedChanged;
            // 
            // textBox_Name
            // 
            textBox_Name.Location = new Point(153, 59);
            textBox_Name.Name = "textBox_Name";
            textBox_Name.Size = new Size(302, 38);
            textBox_Name.TabIndex = 4;
            textBox_Name.TextChanged += textBox_Name_TextChanged;
            // 
            // toolStrip1
            // 
            toolStrip1.ImageScalingSize = new Size(32, 32);
            toolStrip1.Items.AddRange(new ToolStripItem[] { toolStripButton2, toolStripButton3, toolStripButton_Delete, toolStripButton4 });
            toolStrip1.Location = new Point(0, 0);
            toolStrip1.Name = "toolStrip1";
            toolStrip1.Size = new Size(1804, 42);
            toolStrip1.TabIndex = 2;
            toolStrip1.Text = "toolStrip1";
            toolStrip1.ItemClicked += toolStrip1_ItemClicked;
            // 
            // toolStripButton2
            // 
            toolStripButton2.DisplayStyle = ToolStripItemDisplayStyle.Image;
            toolStripButton2.Image = (Image)resources.GetObject("toolStripButton2.Image");
            toolStripButton2.ImageTransparentColor = Color.Magenta;
            toolStripButton2.Name = "toolStripButton2";
            toolStripButton2.Size = new Size(46, 36);
            toolStripButton2.Text = "toolStripButton2";
            // 
            // toolStripButton3
            // 
            toolStripButton3.DisplayStyle = ToolStripItemDisplayStyle.Image;
            toolStripButton3.Image = (Image)resources.GetObject("toolStripButton3.Image");
            toolStripButton3.ImageTransparentColor = Color.Magenta;
            toolStripButton3.Name = "toolStripButton3";
            toolStripButton3.Size = new Size(46, 36);
            toolStripButton3.Text = "toolStripButton3";
            // 
            // toolStripButton_Delete
            // 
            toolStripButton_Delete.DisplayStyle = ToolStripItemDisplayStyle.Image;
            toolStripButton_Delete.Image = (Image)resources.GetObject("toolStripButton_Delete.Image");
            toolStripButton_Delete.ImageTransparentColor = Color.Magenta;
            toolStripButton_Delete.Name = "toolStripButton_Delete";
            toolStripButton_Delete.Size = new Size(46, 36);
            toolStripButton_Delete.Text = "toolStripButton1";
            // 
            // toolStripButton4
            // 
            toolStripButton4.DisplayStyle = ToolStripItemDisplayStyle.Image;
            toolStripButton4.Image = (Image)resources.GetObject("toolStripButton4.Image");
            toolStripButton4.ImageTransparentColor = Color.Magenta;
            toolStripButton4.Name = "toolStripButton4";
            toolStripButton4.Size = new Size(46, 36);
            toolStripButton4.Text = "toolStripButton4";
            // 
            // textBox1
            // 
            textBox1.Location = new Point(252, 45);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(1520, 38);
            textBox1.TabIndex = 4;
            // 
            // Form_Employee_Management
            // 
            AutoScaleDimensions = new SizeF(14F, 31F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1804, 858);
            Controls.Add(textBox1);
            Controls.Add(toolStrip1);
            Controls.Add(groupBox_Search_Conditions);
            Controls.Add(dataGridView);
            Name = "Form_Employee_Management";
            Text = "员工管理";
            Load += Form_Employee_Management_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridView).EndInit();
            groupBox_Search_Conditions.ResumeLayout(false);
            groupBox_Search_Conditions.PerformLayout();
            toolStrip1.ResumeLayout(false);
            toolStrip1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dataGridView;
        private GroupBox groupBox_Search_Conditions;
        private CheckBox checkBox_Dep;
        private CheckBox checkBox_Name;
        private TextBox textBox_Name;
        private CheckBox checkBox_Time;
        private Button button_Search;
        private ComboBox comboBox_Time_End;
        private Label label1;
        private ComboBox comboBox_Time_Start;
        private ComboBox comboBox_Department;
        private ToolStrip toolStrip1;
        private ToolStripButton toolStripButton_Delete;
        private ToolStripButton toolStripButton2;
        private ToolStripButton toolStripButton3;
        private ToolStripButton toolStripButton4;
        private TextBox textBox1;
    }
}