﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRMSystem.Model
{
    public class ConditionForSearch
    {
        public bool IsVaild { get; set; }
        public bool IsInDate { get; set; }
        public string? Name { get; set; }
        public string? InDateFrom { get; set; }
        public string? InDateTo { get; set; }
        public Guid DepartmentId { get; set; }
    }
}
