﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRMSystem.Model
{
    public class LoginUserInfo
    {
        public Operator? LoginUser { get; set; }

        public static LoginUserInfo? user = null;

        public LoginUserInfo() { }

        public static LoginUserInfo GetInstance()
        {
            if (user == null)
            {
                user = new LoginUserInfo();
            }
            return user;
        }

        public void InitMember(Operator op)
        {
            LoginUser = op;
        }
    }


}
