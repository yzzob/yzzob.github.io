﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRMSystem.DAL
{
    public class LogMigrationService
    {
        public HashSet<DateTime> get_log()
        {
            HashSet<DateTime> set = new HashSet<DateTime>();
            string sql = "SELECT ActionDate FROM OperationLog Order by ActionDate Desc";
            SqlDataReader sdr = SqlHelper.ExecuteReader(sql);
            while (sdr.Read())
            {
                DateTime logtime = sdr.GetDateTime(0);
                set.Add(logtime);
            }
            return set;
        }
        public void move_log(DateTime dateTime)
        {
            // 检查表是否存在
            string checkSql = "IF OBJECT_ID('OprationLogBackup', 'U') IS NOT NULL DROP TABLE OprationLogBackup";
            int n=SqlHelper.ExecuteNonQuery(checkSql);

            // 执行 SELECT INTO 查询
            string sql = "SELECT * INTO OprationLogBackup FROM OperationLog WHERE operationlog.ActionDate <= @datetime order by operationlog.ActionDate desc";
            SqlParameter[] sp = new SqlParameter[]
            {
            new SqlParameter("@datetime",dateTime),
            };
            SqlHelper.ExecuteNonQuery(sql, sp);


        }
    }
}
