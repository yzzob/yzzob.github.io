﻿using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRMSystem.DAL
{
    internal class SqlHelper
    {
        private static string? connStr = ConfigurationAccessor.Configuration.GetConnectionString("connStr");
        public static object ExecuteScalar(string sql,params SqlParameter[] parameters)
        {
            using(SqlConnection conn =new SqlConnection(connStr))
            {
                conn.Open();
                SqlCommand comm=new SqlCommand(sql,conn);
                comm.Parameters.AddRange(parameters);
                return comm.ExecuteScalar();
            }
        }
        public static int ExecuteNonQuery(string sql, params SqlParameter[] parameters)
        {
            using(SqlConnection conn = new SqlConnection(connStr))
            {
                conn.Open();
                SqlCommand comm=new SqlCommand(sql,conn);
                comm.Parameters.AddRange(parameters);
                return comm.ExecuteNonQuery();
            }
        }
        public static SqlDataReader ExecuteReader(string sql, params SqlParameter[] parameters)
        {
            SqlConnection conn = new SqlConnection(connStr);
            SqlCommand comm = new SqlCommand(sql,conn);
            comm.Parameters.AddRange(parameters);
            conn.Open();
            return comm.ExecuteReader(CommandBehavior.CloseConnection);
        }
        public static DataTable GetDataTable(string sql, params SqlParameter[] parameters)
        {
            DataTable dt = new DataTable();
            using(SqlConnection conn = new SqlConnection(connStr)) 
            {
                SqlDataAdapter sda = new SqlDataAdapter(sql, conn);
                sda.SelectCommand.Parameters.AddRange(parameters);
                sda.Fill(dt);
                return dt;
            }

        }
    }
}
