﻿
using HRMSystem.Model;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRMSystem.DAL
{
    public class DepartmentManageService
    {
        public DataTable GetDepatmentList()
        {
            DataTable dt = new DataTable();
            string sql = @"
                SELECT Temp.Id AS 编号, Temp.Name AS 部门名称
                FROM (
                    SELECT Id, Name,
                    ROW_NUMBER() OVER (ORDER BY Id DESC) AS RowNum
                    FROM Department
                ) AS Temp";
            return SqlHelper.GetDataTable(sql);
        }
        public DataTable AddDepartment(string name)
        {
            string sql = "INSERT INTO Department (Id, Name) VALUES (@Id, @Name)";
            SqlParameter[] parameters = new SqlParameter[]
            {
                new SqlParameter("@Id", SqlDbType.UniqueIdentifier) { Value = Guid.NewGuid() },
                new SqlParameter("@Name", SqlDbType.NVarChar) { Value = name }
            };
            return SqlHelper.GetDataTable(sql, parameters);
        }

        public void DeleteDepartments(List<Guid> ids)
        {
            string sql = "DELETE FROM Department WHERE Id = @Id";
            foreach (Guid id in ids)
            {
                SqlParameter[] parameters = new SqlParameter[]
                {
                    new SqlParameter("@Id", id),
                };
                SqlHelper.ExecuteNonQuery(sql, parameters);
            }
        }

        public DataTable EditDepartments(string oldName, string newName)
        {
            string sql = "UPDATE Department SET Name = @NewName WHERE Name = @OldName; SELECT * FROM Department";
            SqlParameter[] parameters = new SqlParameter[]
            {
                new SqlParameter("@NewName",newName),
                new SqlParameter("OldName",oldName),
            };
            return SqlHelper.GetDataTable(sql, parameters);
        }
        public DataTable QueryDepartment(string name)
        {
            string sql = "SELECT * FROM Department WHERE name = @Name";
            SqlParameter[] parameters = new SqlParameter[]
            {
                new SqlParameter("@Name",name),
            };
            return SqlHelper.GetDataTable(sql, parameters);
        }
    }
}
