﻿using Azure;
using HRMSystem.Model;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRMSystem.DAL
{
    public class OperationLogService
    {
        public bool AddLog(OperationLog log)
        {
            string sql = "INSERT INTO OperationLog VALUES(@Id,@OperatorId,@ActionDate,@ActionDesc)";
            SqlParameter[] parameters = new SqlParameter[]
            {
                new SqlParameter("@Id",log.Id),
                new SqlParameter("@OperatorId",log.Operatorld),
                new SqlParameter("@ActionDate",log.ActionDate),
                new SqlParameter("@ActionDesc",log.ActionDesc)
            };
            return (int)SqlHelper.ExecuteNonQuery(sql,parameters)>0;
        }
        public int GetLogCount() 
        {
            string sql = "SELECT COUNT(*) FROM OperationLog";
            return (int)SqlHelper.ExecuteScalar(sql);
        }
        public DataTable GetLogList(int page, int pageSize)
        {
            DataTable dt = new DataTable();
            //SELECT Temp.Id AS 编号,Operator.RealName AS 操作员, Temp.ActionDate AS 操作时间, Temp.ActionDesc AS 描述 FROM (SELECT TOP (@LogNum) * FROM OperationLog WHERE Id NOT IN (SELECT TOP (@BeforeNum) Id FROM OperationLog)) AS Temp, Operator WHERE Temp.OperatorId = Operator.Id
            string sql = @"
                SELECT Temp.Id AS 编号, Temp.OperatorId AS 操作员ID, ISNULL(Operator.RealName,'unknown') AS 操作员, Temp.ActionDate AS 操作时间, Temp.ActionDesc AS 描述
                FROM (
                    SELECT Id, OperatorId, ActionDate, ActionDesc,
                    ROW_NUMBER() OVER (ORDER BY ActionDate DESC) AS RowNum
                    FROM OperationLog
                ) AS Temp
                LEFT JOIN Operator ON Temp.OperatorId = Operator.Id
                WHERE Temp.RowNum BETWEEN @StartRow AND @EndRow";
            int startRow = (page - 1) * pageSize+1;
            int endRow = startRow + pageSize - 1;
            SqlParameter paramStartRow = new SqlParameter("@StartRow", startRow);
            SqlParameter paramEndRow = new SqlParameter("@EndRow", endRow);
            return SqlHelper.GetDataTable(sql, paramStartRow, paramEndRow);
        }
    }
}
