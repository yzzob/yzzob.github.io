﻿using HRMSystem.Model;
using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.PortableExecutable;
using System.Text;
using System.Threading.Tasks;
using System.Data;
namespace HRMSystem.DAL
{
     public class EmployeeManagementService
     {
        public HashSet<string> GetDepartment()
        {
            HashSet<string> set = new HashSet<string>();
            string sql = "SELECT Name FROM Department";
            SqlDataReader sdr= SqlHelper.ExecuteReader(sql);
            while (sdr.Read())
            {
                string departmentName = sdr.GetString(0);
                set.Add(departmentName);
            }
            return set;
        }
        public HashSet<DateTime> GetInDay()
        {
            HashSet<DateTime> set = new HashSet<DateTime>();
            string sql = "SELECT InDay FROM Employee ORDER BY InDay ASC"; // ASC 升序排列，DESC 降序排列
            SqlDataReader sdr = SqlHelper.ExecuteReader(sql);
            while (sdr.Read())
            {
                DateTime datetime = sdr.GetDateTime(0); // 使用 GetDateTime 方法获取日期时间值
                set.Add(datetime);
            }
            return set;
        }
        public Guid GetGuid(string nm)
        {
            string sql_Guid = "select Department.Id from Employee join Department on Department.Id = Employee.DepartmentId where Department.Name=@Name";
            SqlParameter sqlParameter = new SqlParameter("@Name", nm);
            object result = SqlHelper.ExecuteScalar(sql_Guid, sqlParameter);
            if (result != null && result != DBNull.Value && Guid.TryParse(result.ToString(), out Guid uid))
            {
                return uid;
            }
            return Guid.NewGuid();
        }
        public DataTable GetData(ConditionForSearch cfs)
        {
            DataTable dt = new DataTable();
            List<SqlParameter> parameters = new List<SqlParameter>();
            string sql = "select * from Employee join Department on Department.Id = Employee.DepartmentId where 1=1";
            if (!string.IsNullOrEmpty(cfs.Name))
            {
                sql += $" and Employee.Name = @Name";
                parameters.Add(new SqlParameter("@Name", cfs.Name));
            }

            if (cfs.DepartmentId != Guid.Empty)
            {
                sql += $" and Department.Id = @ID";
                parameters.Add(new SqlParameter("@ID", cfs.DepartmentId));
            }
            if (!string.IsNullOrEmpty(cfs.InDateFrom))
            {
                sql += " and Employee.InDay >= @day_1";
                parameters.Add(new SqlParameter("@day_1", cfs.InDateFrom));
            }

            //if (!string.IsNullOrEmpty(cfs.InDateTo))
            //{
            //    sql += " and Employee.InDay <= @day_2";
            //    parameters.Add(new SqlParameter("@day_2", cfs.InDateTo));
            //}
            if (!string.IsNullOrEmpty(cfs.InDateTo))
            {
                DateTime endDate = DateTime.Parse(cfs.InDateTo);
                endDate = endDate.AddDays(1);
                cfs.InDateTo = endDate.ToString("yyyy-MM-dd");
                sql += " and Employee.InDay < @day_2"; // 注意这里使用 < 而不是 <=
                parameters.Add(new SqlParameter("@day_2", cfs.InDateTo));
            }
            dt = SqlHelper.GetDataTable(sql, parameters.ToArray());
            return dt;
        }
     }
}
