﻿using HRMSystem.Model;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRMSystem.DAL
{
    public class OperatorService
    {
        public  Operator? GetOperator(string un) 
        {
            Operator? op = null;
            string sql = "SELECT * FROM Operator WHERE UserName =@UserName";
            SqlParameter paramUserName=new SqlParameter("@UserName",un);
            SqlDataReader sdr =SqlHelper.ExecuteReader(sql, paramUserName);
            if (sdr.Read())
            {
                op = new Operator()
                {
                    Id = (Guid)sdr["Id"],
                    UserName = (string)sdr["UserName"],
                    Password = (string)sdr["Password"],
                    IsDeleted = (bool)sdr["IsDeleted"],
                    RealName = (string)sdr["RealName"],
                    IsLocked = (bool)sdr["IsLocked"],
                    IsAdmin = (bool)sdr["IsAdmin"]
                };   
            }
            sdr.Close();
            return op;
        }
        public int  ChangePassword(string un,string old_pwd,string new_pwd) 
        {
            string md5_new_pwd = CommonHelper.GetMD5(new_pwd);
            string sql = "UPDATE Operator SET Password = @NewPassword WHERE UserName = @Username AND Password = @Password";
            SqlParameter[] parameters = new SqlParameter[]
            {
                new SqlParameter("@Username",un),
                new SqlParameter("@Password",old_pwd),
                new SqlParameter("@NewPassword",md5_new_pwd),
            };
            return (int)SqlHelper.ExecuteNonQuery(sql, parameters);
        }
        public int ResetPassword(string un, string new_pwd)
        {
            string md5_new_pwd = CommonHelper.GetMD5(new_pwd);
            string sql = "UPDATE Operator SET Password = @NewPassword WHERE UserName = @Username";
            SqlParameter[] parameters = new SqlParameter[]
            {
                new SqlParameter("@Username",un),
                new SqlParameter("@NewPassword",md5_new_pwd),
            };

            return (int)SqlHelper.ExecuteNonQuery(sql, parameters);
        
        }
    }
}
