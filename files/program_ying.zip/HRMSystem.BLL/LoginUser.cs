﻿using HRMSystem.DAL;
using HRMSystem.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRMSystem.BLL
{
    public class LoginUser
    {
        public string UserName;
        public string password;
        public string new_pwd;
        public LoginUser(string un,string pwd,string new_pwd) 
        {
            this.UserName = un;
            this.password = pwd;
            this.new_pwd = new_pwd;
        }
        public bool IsValid()
        {
            OperationLogService logServ = new OperationLogService();
            OperatorService opServ = new OperatorService();
            Operator? op = opServ.GetOperator(UserName);
            OperationLog log = new OperationLog()
            {
                Id = Guid.NewGuid(),
                ActionDate = DateTime.Now,

            };

            if (op != null && op.Password == password)
            {
                LoginUserInfo? lui=LoginUserInfo.GetInstance();
                if (lui != null )
                {
                  lui.LoginUser = op;
                }
                log.Operatorld = op.Id;
                log.ActionDesc = $"{op.RealName}成功登录了系统";
                logServ.AddLog(log);
                return true;
            }
            else
            {
                if(op != null)
                {
                    log.Operatorld = op.Id;
                    log.ActionDesc = $"有人用用户名{op.UserName}来尝试登录,但是密码不正确! ";

                }
                else
                {
                    log.Operatorld = Guid.Empty;
                    log.ActionDesc = $"有人用用户名{UserName}来尝试登录,但是该用户不存在! ";
                }
                logServ.AddLog(log);
                return false;
            }
        }
        public int Change_Password_IsValid()
        {
            OperatorService opServ = new OperatorService();
            int flag = opServ.ChangePassword(UserName,password,new_pwd);
            return flag;
        }
        public int Reset_Password_IsValid()
        {
            OperatorService opServ = new OperatorService();
            int flag = opServ.ResetPassword(UserName,new_pwd);
            return flag;
        }
    }
}
